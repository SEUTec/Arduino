
Install "Soft_LCD-I2C" library before running this example.

"Soft_LCD-I2C" library is in libraries folder.
